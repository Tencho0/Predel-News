using Microsoft.Extensions.DependencyInjection;

namespace PredelNews.BackofficeExtensions.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddPredelNewsBackofficeExtensions(this IServiceCollection services)
    {
        return services;
    }
}
